# Automatic update of dependencies

If you want to automatically update dependencies, you can connect [Renovate](https://github.com/marketplace/renovate) for your project.

---

Previous: [Benchmarking](benchmarking.md)

Next: [Translations](translations.md)