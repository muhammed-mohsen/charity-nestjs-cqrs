/**
 * Application-level providers for the Account bounded context.
 * Add command handlers, query handlers, event handlers, etc. here.
 */

export const AccountApplicationProviders = [
  // TODO: add command/query/event handlers here
];
