import { AggregateRoot } from "@nestjs/cqrs";
import { Account } from "../account/account";
import { SessionId } from "./session-id";

export type SessionEssentialProps = {
    id: SessionId;
    account: Account;
    hash: string;
}
export type SessionOptionalProps = {
    createdAt: Date;
    updatedAt: Date;
    deletedAt: Date;
}
export type SessionProps = SessionEssentialProps & SessionOptionalProps;
export interface Session{};

export class SessionImplement extends AggregateRoot implements Session {  
  
    private constructor(
        private readonly id: SessionId,
        private readonly hash: string,
        private readonly account: Account,
    ) {
        super();
    }
    static create(id: SessionId, hash: string, account: Account): Session {
        const _id = SessionId.generate();
        return new SessionImplement(_id, hash, account);
    }
  
}