export class RoleSchema {
  _id: string;

  name?: string;
}
