import { DomainModel } from "./domain-model";

export interface ValueObject  extends DomainModel{
    equals(other: ValueObject): boolean;
  }
  