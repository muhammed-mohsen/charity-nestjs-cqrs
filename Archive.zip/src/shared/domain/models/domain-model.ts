export interface DomainModel {
   
}