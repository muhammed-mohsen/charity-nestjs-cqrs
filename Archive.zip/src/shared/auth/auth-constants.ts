export const AUTH_ISSUER = 'https://tech-mentors.net';
export const AUTH_SUBJECT = 'authentication';
