export type TokenType = 'access' | 'refresh';
