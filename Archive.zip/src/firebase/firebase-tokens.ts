// src/firebase/firebase.tokens.ts
export const FIREBASE_ADMIN = Symbol('FIREBASE_ADMIN');
export const FIREBASE_PROVIDER = Symbol('FIREBASE_PROVIDER');
