export interface MailData {
  to: string;
  subject: string;
  html?: string;
  text?: string;
}
